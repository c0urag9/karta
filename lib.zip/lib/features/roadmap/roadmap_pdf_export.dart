import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:my_business_app/features/roadmap/roadmap_provider.dart';

class RoadmapPdfExport {
  static Future<void> export(BuildContext context, Roadmap roadmap) async {
    final doc = pw.Document();

    // Цвета
    const purple  = PdfColor.fromInt(0xFF534AB7);
    const blue    = PdfColor.fromInt(0xFF378ADD);
    const teal    = PdfColor.fromInt(0xFF1D9E75);
    const amber   = PdfColor.fromInt(0xFFEF9F27);
    const darkBg  = PdfColor.fromInt(0xFFF8F9FA);
    const dark    = PdfColor.fromInt(0xFF1A1A2E);
    const grey    = PdfColor.fromInt(0xFF888888);
    const white   = PdfColors.white;

    // Цвета категорий
    PdfColor categoryColor(TaskCategory cat) {
      switch (cat) {
        case TaskCategory.finance:    return teal;
        case TaskCategory.marketing:  return blue;
        case TaskCategory.operations: return amber;
        case TaskCategory.hr:         return const PdfColor.fromInt(0xFF9B59B6);
        case TaskCategory.digital:    return purple;
        case TaskCategory.strategy:   return const PdfColor.fromInt(0xFFE74C3C);
      }
    }

    // Период → цвет
    PdfColor periodColor(TaskPeriod p) {
      switch (p) {
        case TaskPeriod.threeMonths:  return teal;
        case TaskPeriod.sixMonths:    return blue;
        case TaskPeriod.twelveMonths: return purple;
      }
    }

    String periodLabel(TaskPeriod p) {
      switch (p) {
        case TaskPeriod.threeMonths:  return '1–3 месяца';
        case TaskPeriod.sixMonths:    return '3–6 месяцев';
        case TaskPeriod.twelveMonths: return '6–12 месяцев';
      }
    }

    String statusLabel(TaskStatus s) {
      switch (s) {
        case TaskStatus.pending:    return 'Не начата';
        case TaskStatus.inProgress: return 'В работе';
        case TaskStatus.done:       return 'Выполнено';
      }
    }

    PdfColor statusColor(TaskStatus s) {
      switch (s) {
        case TaskStatus.pending:    return grey;
        case TaskStatus.inProgress: return purple;
        case TaskStatus.done:       return teal;
      }
    }

    final totalTasks = roadmap.tasks.length;
    final doneTasks  = roadmap.tasks.where((t) => t.status == TaskStatus.done).length;
    final now = DateTime.now();
    final dateStr = '${now.day.toString().padLeft(2,'0')}.${now.month.toString().padLeft(2,'0')}.${now.year}';

    // ── СТРАНИЦА 1: Обложка + резюме ──────────────────────────

    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(0),
      build: (ctx) => pw.Column(children: [

        // Шапка-градиент
        pw.Container(
          width: double.infinity,
          padding: const pw.EdgeInsets.fromLTRB(40, 40, 40, 32),
          decoration: const pw.BoxDecoration(
            gradient: pw.LinearGradient(
              colors: [purple, blue],
              begin: pw.Alignment.topLeft,
              end: pw.Alignment.bottomRight,
            ),
          ),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Row(children: [
              pw.Container(
                padding: const pw.EdgeInsets.all(10),
                decoration: pw.BoxDecoration(
                  color: white.withOpacity(0.2),
                  borderRadius: pw.BorderRadius.circular(10),
                ),
                child: pw.Text('БН', style: pw.TextStyle(
                  color: white, fontSize: 18, fontWeight: pw.FontWeight.bold)),
              ),
              pw.SizedBox(width: 14),
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('Бизнес-навигатор',
                    style: pw.TextStyle(color: white, fontSize: 14, fontWeight: pw.FontWeight.bold)),
                pw.Text('AI-платформа развития МСБ',
                    style: pw.TextStyle(color: white.withOpacity(0.7), fontSize: 10)),
              ]),
              pw.Spacer(),
              pw.Text(dateStr, style: pw.TextStyle(color: white.withOpacity(0.7), fontSize: 10)),
            ]),
            pw.SizedBox(height: 28),
            pw.Text('Дорожная карта развития',
                style: pw.TextStyle(color: white.withOpacity(0.8), fontSize: 13)),
            pw.SizedBox(height: 6),
            pw.Text(roadmap.companyName,
                style: pw.TextStyle(color: white, fontSize: 28, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 20),
            pw.Row(children: [
              _statBadge('$totalTasks задач', white),
              pw.SizedBox(width: 12),
              _statBadge('12 месяцев', white),
              pw.SizedBox(width: 12),
              _statBadge('$doneTasks выполнено', white),
            ]),
          ]),
        ),

        // Тело страницы
        pw.Expanded(child: pw.Container(
          color: darkBg,
          padding: const pw.EdgeInsets.all(32),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [

            // Резюме
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.all(18),
              decoration: pw.BoxDecoration(
                color: white,
                borderRadius: pw.BorderRadius.circular(10),
                border: pw.Border.all(color: purple.withOpacity(0.2)),
              ),
              child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('Резюме анализа',
                    style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: dark)),
                pw.SizedBox(height: 8),
                pw.Text(roadmap.executiveSummary,
                    style: pw.TextStyle(fontSize: 11, color: dark, lineSpacing: 4)),
              ]),
            ),

            pw.SizedBox(height: 24),

            // Статистика по периодам
            pw.Text('Обзор по периодам',
                style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: dark)),
            pw.SizedBox(height: 12),
            pw.Row(children: TaskPeriod.values.map((p) {
              final tasks = roadmap.byPeriod(p);
              final done  = tasks.where((t) => t.status == TaskStatus.done).length;
              final color = periodColor(p);
              return pw.Expanded(child: pw.Container(
                margin: pw.EdgeInsets.only(right: p.index < 2 ? 10 : 0),
                padding: const pw.EdgeInsets.all(14),
                decoration: pw.BoxDecoration(
                  color: white,
                  borderRadius: pw.BorderRadius.circular(10),
                  border: pw.Border.all(color: color.withOpacity(0.3)),
                ),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                  pw.Text(periodLabel(p),
                      style: pw.TextStyle(fontSize: 10, color: color, fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 6),
                  pw.Text('${tasks.length} задач',
                      style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: dark)),
                  pw.SizedBox(height: 4),
                  pw.Text('$done выполнено',
                      style: pw.TextStyle(fontSize: 10, color: color)),
                  pw.SizedBox(height: 8),
                  pw.Container(
                    height: 4,
                    decoration: pw.BoxDecoration(
                      color: color.withOpacity(0.15),
                      borderRadius: pw.BorderRadius.circular(2),
                    ),
                    child: pw.FractionallySizedBox(
                      widthFactor: tasks.isEmpty ? 0 : done / tasks.length,
                      child: pw.Container(
                        decoration: pw.BoxDecoration(
                          color: color,
                          borderRadius: pw.BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),
                ]),
              ));
            }).toList()),
          ]),
        )),
      ]),
    ));

    // ── СТРАНИЦЫ С ЗАДАЧАМИ ────────────────────────────────────

    for (final period in TaskPeriod.values) {
      final tasks = roadmap.byPeriod(period);
      if (tasks.isEmpty) continue;

      final pColor = periodColor(period);

      doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(32, 32, 32, 32),
        header: (ctx) => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 14),
          decoration: const pw.BoxDecoration(
            border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey300, width: 0.5)),
          ),
          child: pw.Row(children: [
            pw.Container(
              padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: pw.BoxDecoration(
                color: pColor,
                borderRadius: pw.BorderRadius.circular(20),
              ),
              child: pw.Text(periodLabel(period),
                  style: pw.TextStyle(color: white, fontSize: 11, fontWeight: pw.FontWeight.bold)),
            ),
            pw.SizedBox(width: 12),
            pw.Text(roadmap.companyName,
                style: pw.TextStyle(fontSize: 11, color: grey)),
            pw.Spacer(),
            pw.Text('${tasks.length} задач',
                style: pw.TextStyle(fontSize: 11, color: grey)),
          ]),
        ),
        footer: (ctx) => pw.Container(
          padding: const pw.EdgeInsets.only(top: 10),
          decoration: const pw.BoxDecoration(
            border: pw.Border(top: pw.BorderSide(color: PdfColors.grey300, width: 0.5)),
          ),
          child: pw.Row(children: [
            pw.Text('Бизнес-навигатор · Дорожная карта развития',
                style: pw.TextStyle(fontSize: 9, color: grey)),
            pw.Spacer(),
            pw.Text('Стр. ${ctx.pageNumber}',
                style: pw.TextStyle(fontSize: 9, color: grey)),
          ]),
        ),
        build: (ctx) => tasks.map((task) {
          final catColor = categoryColor(task.category);
          final sColor   = statusColor(task.status);
          final isDone   = task.status == TaskStatus.done;

          return pw.Container(
            margin: const pw.EdgeInsets.only(bottom: 14),
            decoration: pw.BoxDecoration(
              color: isDone ? teal.withOpacity(0.05) : white,
              borderRadius: pw.BorderRadius.circular(10),
              border: pw.Border.all(
                color: isDone ? teal.withOpacity(0.3) : PdfColors.grey300,
                width: 0.5,
              ),
            ),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [

              // Верхняя полоска категории
              pw.Container(
                height: 3,
                decoration: pw.BoxDecoration(
                  color: catColor,
                  borderRadius: const pw.BorderRadius.only(
                    topLeft: pw.Radius.circular(10),
                    topRight: pw.Radius.circular(10),
                  ),
                ),
              ),

              pw.Padding(
                padding: const pw.EdgeInsets.all(16),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [

                  // Бейджи
                  pw.Row(children: [
                    pw.Container(
                      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: pw.BoxDecoration(
                        color: catColor.withOpacity(0.1),
                        borderRadius: pw.BorderRadius.circular(5),
                      ),
                      child: pw.Text(task.category.label,
                          style: pw.TextStyle(fontSize: 9, color: catColor, fontWeight: pw.FontWeight.bold)),
                    ),
                    pw.SizedBox(width: 8),
                    pw.Container(
                      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: pw.BoxDecoration(
                        color: sColor.withOpacity(0.1),
                        borderRadius: pw.BorderRadius.circular(5),
                      ),
                      child: pw.Text(statusLabel(task.status),
                          style: pw.TextStyle(fontSize: 9, color: sColor)),
                    ),
                    pw.Spacer(),
                    pw.Text('Приоритет: ${task.priority}',
                        style: pw.TextStyle(fontSize: 9, color: grey)),
                  ]),

                  pw.SizedBox(height: 8),

                  // Заголовок
                  pw.Text(task.title,
                      style: pw.TextStyle(
                        fontSize: 13, fontWeight: pw.FontWeight.bold, color: dark,
                        decoration: isDone ? pw.TextDecoration.lineThrough : null,
                      )),

                  if (task.description.isNotEmpty) ...[
                    pw.SizedBox(height: 6),
                    pw.Text(task.description,
                        style: pw.TextStyle(fontSize: 10, color: grey, lineSpacing: 3)),
                  ],

                  if (task.result.isNotEmpty) ...[
                    pw.SizedBox(height: 10),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(10),
                      decoration: pw.BoxDecoration(
                        color: teal.withOpacity(0.08),
                        borderRadius: pw.BorderRadius.circular(6),
                        border: pw.Border.all(color: teal.withOpacity(0.2), width: 0.5),
                      ),
                      child: pw.Row(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text('▶ ', style: pw.TextStyle(fontSize: 9, color: teal)),
                          pw.Expanded(child: pw.Text(task.result,
                              style: pw.TextStyle(fontSize: 10, color: teal, lineSpacing: 3))),
                        ],
                      ),
                    ),
                  ],
                ]),
              ),
            ]),
          );
        }).toList(),
      ));
    }

    // Сохраняем PDF
    await Printing.layoutPdf(
      onLayout: (_) async => doc.save(),
      name: 'Дорожная_карта_${roadmap.companyName.replaceAll(' ', '_')}.pdf',
    );
  }

  static pw.Widget _statBadge(String text, PdfColor color) => pw.Container(
    padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: pw.BoxDecoration(
      color: color.withOpacity(0.15),
      borderRadius: pw.BorderRadius.circular(20),
    ),
    child: pw.Text(text,
        style: pw.TextStyle(color: color, fontSize: 10, fontWeight: pw.FontWeight.bold)),
  );
}
